import React from "react";

import Stopwatch from "../Stopwatch";

export default function App() {
  return <Stopwatch />;
}
